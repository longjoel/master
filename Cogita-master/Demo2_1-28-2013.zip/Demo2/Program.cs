﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;

using CogitaGameEntities;
using CogitaTerrainObjects;


namespace Demo2
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            int mouseX = 0;
            int mouseY = 0;

           int baseTexture; 

            using (var w = new GameWindow(640, 480))
            {
                w.CursorVisible = false;

                w.RenderFrame += (o, e) => {
                    GL.ClearColor(Color.Gray);
                    GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

                    CogitaGameEntities.CogitaGameInstance.Instance.Player.Camera.UseCamera();

                    GL.Enable(EnableCap.Texture2D);
                    CogitaGameEntities.CogitaGameInstance.Instance.MapCursor.Draw();
                    GL.Disable(EnableCap.Texture2D);

                    w.SwapBuffers();

                };
                
                w.UpdateFrame += (o, e) => {
                    CogitaGameEntities.CogitaGameInstance.Instance.MapCursor.Update();
                    CogitaTerrainObjects.EventPumps.UIThreadEventPump.Instance.DoWork();
                    CogitaGameEntities.CogitaGameInstance.Instance.DoPhysics(e.Time);

                    var gi = CogitaGameEntities.CogitaGameInstance.Instance;
                    var player = gi.Player;

                    ProcessKeyPresses(w, player);

                    if (w.Keyboard[OpenTK.Input.Key.Escape])
                        w.Exit();

                    var mState = OpenTK.Input.Mouse.GetState();
                    var mdx = mState.X - mouseX;
                    var mdy = mState.Y - mouseY;

                    mouseX = mState.X;
                    mouseY = mState.Y;

                    player.Pitch += ((double)mdy / 200.0);
                    player.Yaw += ((double)mdx / 200.0);
                };

                w.Load += (o, e) => 
                {
                    baseTexture = GenTexture("../res/block.png");
                };

                w.Run(60);
            }
        }


        static int GenTexture(string path)
        {
            GL.Enable(EnableCap.CullFace);
            GL.Enable(EnableCap.DepthTest);

            var texture = GL.GenTexture();

            GL.BindTexture(TextureTarget.Texture2D, texture);

            Bitmap bx = new Bitmap(path);

            BitmapData data = bx.LockBits(new Rectangle(0, 0, bx.Width, bx.Height),
               ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, data.Width, data.Height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Bgra, PixelType.UnsignedByte, data.Scan0);

            bx.UnlockBits(data);


            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);


            bx.Dispose();

            return texture;
        }

        private static void ProcessKeyPresses(GameWindow w, Player player)
        {
            bool isMoving = false;

            var kstate = OpenTK.Input.Keyboard.GetState();
           
            
            if (kstate[OpenTK.Input.Key.Q])
            {
                player.Yaw -= 1.25;
            }

            if (kstate[OpenTK.Input.Key.Space] && Math.Abs(player.VY) < 0.25 && player.CanJump)
            {
                player.VY += 5;
                player.CanJump = false;
            }

            if (kstate[OpenTK.Input.Key.E])
            {
                player.Yaw += 1.25;
            }

            if (kstate[OpenTK.Input.Key.D])
            {
                player.Move(player.Yaw, 9);
                isMoving = true;
            }

            if (kstate[OpenTK.Input.Key.A])
            {
                player.Move(player.Yaw + 180, 4);
                isMoving = true;
            }

            if (kstate[OpenTK.Input.Key.S])
            {
                player.Move(player.Yaw + 90, 4);
                isMoving = true;
            }

            if (kstate[OpenTK.Input.Key.W])
            {
                player.Move(player.Yaw - 90, 9);
                isMoving = true;
            }

            if (isMoving)
                player.Y += 0.025;
        }       
    }
}
